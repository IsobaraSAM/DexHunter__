//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-C1lDQq5-.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/api/discovery",
			"/api/health",
			"/api/pump-audit",
			"/api/pump-diagnostic",
			"/api/pump-fresh",
			"/api/pump-resolve",
			"/api/pump-token",
			"/api/pumpfun-audit",
			"/api/pumpfun-debug",
			"/api/pumpfun-diagnostic",
			"/api/pumpfun-new",
			"/api/token-holders",
			"/api/argus/launches",
			"/api/argus/stats"
		],
		preloads: ["/assets/index-BpWVjgMn.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BpWVjgMn.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DAxhUyTw.js"]
	}
} });
//#endregion
export { tsrStartManifest };
